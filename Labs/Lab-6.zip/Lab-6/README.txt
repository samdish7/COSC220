					README file
1.)	BubbleSort:     |BEST      |<><><><><><>|WORST       |
			|----------|------------|------------|
	Small:		|O(5)      |		|O(5^2)      |
	Medium:		|O(100)    |            |O(100^2)    |
	Large:		|O(10000)  |            |O(10000^2)  |
			|----------|------------|------------|
	SelectionSort:	|----------|------------|------------|
			|----------|------------|------------|
	Small:		|O(5^2)	   |		|O(5^2)	     |
	Medium:		|O(100^2)  |		|O(100^2)    |
	Large:		|O(10000^2)|		|O(10000^2)  |
			|----------|------------|------------|
	InsertionSort:	|----------|------------|------------|
			|----------|------------|------------|
	Small:		|O(5)	   |		|O(5^2)	     |
	Medium:		|O(100)	   |		|O(100^2)    |
	Large:		|O(10000)  |		|O(10000^2)  |

2.)	The timing increases as the number of elements increases, the size doesn't matter because ints take up the same amount of memory regardless.  Just because you double the size of the array, doesn't mean you will have a time four times larger, it all depends on the elements in the array.

3.)	On spreadsheet

4.)	Best case for each of the sorts was the smallest one. Bubble performed the worst of them all, however, selection seemed to be best with larger arrays that are worst case.
