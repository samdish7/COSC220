The delete function doesn't work, nor do I have course. If you try to input any of the courses in, it will give you a seg fault.
The update function will only work for the first student in the list. It will ask you what you want to update for any other student if it finds it, but nothing will be updated.
