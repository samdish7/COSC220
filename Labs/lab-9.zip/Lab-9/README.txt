									Sam Disharoon
					READ ME file
	I was able to get the length function, and copy constructor to work. However, there is either something wrong with my logic on the operator function, or I just can't figure out how to insert it correctly, so the insert(int, payroll), assign, and remove classes do not work.
