//Header file lab 8
//Sam Disharoon

#ifndef LAB8_H
#define LAB8_H

void quickSort(int[],int,int);
int partition(int[],int,int);
void swap(int&,int&);

#endif
