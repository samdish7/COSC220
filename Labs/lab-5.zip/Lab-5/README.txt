									Sam Disharoon
					READ ME file
	Everything works with an exception of the Copy CTOR and the Assignment operator. It does not print in reverse because you never told us to push back what we pop out. If we did re push them, the list would print out in reverse order. 
