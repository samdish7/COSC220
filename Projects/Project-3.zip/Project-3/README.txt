					README file
I took a huge L on this project. I got the SUList working, but I didn't implement the Stack, Queue, or payroll objects.  Figured turning in what little I had was better than nothing.
