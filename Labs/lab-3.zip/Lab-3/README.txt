									Sam Disharoon
					READ ME file
	This program takes different employees and tells how much they got paid during a week.  The first 3 are hardcoded, the last 3 are read from the file "emp.txt". No user input.
