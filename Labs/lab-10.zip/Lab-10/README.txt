					README file
	Not sure why, but neither the copy CTOR nor the operator= work.  I tried them both and they just seg fault.  I looked at my last lab as a reference because that lab worked, but it still failed. Not sure what I did wrong.
